# Festival Finder
Save feature will be gesture based.(no gesture in wireframe)
Open website button in detail view will open modalView to the TicketMaster listing
Will include location based search inplace of traditional search box
